﻿import  * as MainPage from "./mainpage.js";
import  * as CameraScreen from "./index.js";
import  * as FallingGenes from "./games/falling_genes.js";
import  * as CardFlip from "./games/card_flip.js";
import  * as MCQ from "./games/mcq.js";

var mainScreen;
export var flowerInformation;
var infoInit = false;

var fallingGenes, cardFlip, mcq;

var lastSwipedXPos = 0, carouselSlider, imageModal;

var audioPlaying = false;


class Game {
    constructor(name, description) {

        this.name = name;
        this.description = description;

    }
    
}

class Question {


    constructor(question, options, answer)
    {
        this.question = question;
        this.options = options; // {A: , B:}
        this.answer = answer;
    }
}



function initGames()
{
    
    
    
    fallingGenes = new Game("Falling Genes", "Catch the correct falling genes! <br> <br> " +
        "Get one point for catching the correct gene. Lose 5 seconds if you catch the wrong gene! :( ");

    cardFlip = new Game("Card Flip", 
        "Flip the cards and match the cards with the correct definition!");

    mcq = new Game("MCQ",
        "Answer the multiple-choice questions! Correct answers give you one point!");
    
    

    console.log(fallingGenes)
}

class Flower {
    
    constructor(gameData, description, modelPath, scale, secondScale, audio, game) {
        
        this.gameData = gameData;
        this.description = description;
        
        this.modelPath = modelPath;
        this.scale = scale;
        this.secondScale = secondScale;
        this.audio = audio;
        this.game = game;
    }
    
}

var listOfFlowers;

function initFlowers()
{
    listOfFlowers = {
        "ciku" : new Flower(["A", "B", "C", "D", "E"], "Ciku (Manilkara zapota) is a delicious, tropical fruit crop" +
            ", popular for its nutritional values. It's cultivated " +
            "widely in tropical countries like Malaysia, " +
            "Thailand, and Indonesia. When ripe, the fruit's pulp is an" +
            " earthy orange color, with a notably sweet, malty flavor. " +
            "Besides its fruit, Ciku also produces milky white sap from its bark, " +
            "which is used to make chewing gum!",
            './models/chiku/Chiku.fbx', 15, 0.5,
            "sounds/chiku.mp3", fallingGenes),

        "daisy" : new Flower(null, "This is a Daisy!! \nLorem ipsum dolor sit amet, c\n" +
            "            onsectetur adipiscing elit, sed do eiusmod tempor incididunt ut\n" +
            "            labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation u\n" +
            "            llamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in\n" +
            "            reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
            './models/stone/Mocha.fbx', 0.1, 0.003,
            "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3", cardFlip),

        "daisy2" : new Flower([new Question("Select A as the answer!", {"A" : "The answer is... A!",
                    "B" : "The answer is... B!",
                    "C" : "The answer is... C!"},

                "A"

                ),

                new Question("Select B as the answer!", {"A" : "The answer is... A!",
                        "B" : "The answer is... B!",
                        "C" : "The answer is... C!"},

                    "B"

                ),

                new Question("Select C as the answer!", {"A" : "The answer is... A!",
                        "B" : "The answer is... B!",
                        "C" : "The answer is... C!"},

                    "C"

                )], "This is a Daisy!! \nLorem ipsum dolor sit amet, c\n" +
            "            onsectetur adipiscing elit, sed do eiusmod tempor incididunt ut\n" +
            "            labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation u\n" +
            "            llamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in\n" +
            "            reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
            './models/stone/Mocha.fbx', 0.1, 0.003,
            "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3", mcq)
    }
}



window.onload = function(){

    //var delayInMilliseconds = 500;

    setTimeout(function() {
        //your code to be executed after 1 second

     


        //var delayInMilliseconds = 2000;

        

            var timerVariable = window.setInterval(function ()
            {
                console.log("test")

                if(!infoInit) 
                {
                    initInformation()
                }
                else
                {
                    window.clearInterval(timerVariable);
                }


            }, 500);

        }, 500);
        
 
}

function openImageModal() 
{
    console.log("test")

    window.scrollTo({ top: 0, behavior: 'smooth' });
    
    imageModal.classList.remove("hide");
    
    document.body.style.overflowY = "hidden";
    document.documentElement.style.overflowY = "hidden";

}

function swipeCarouselImage(e)
{

    console.log(e.touches[0].clientX);
    const style = getComputedStyle(carouselSlider);
    
    var marginLeft;
 
    
    if(e.touches[0].clientX > lastSwipedXPos)
    {
        console.log("Swipe right");
        
        if(parseInt(style.marginLeft.replace("px", "")) < 0)
        {
            marginLeft = 10;
            console.log("yes")
        }
         
    }
    else
    {
        console.log("Swipe left");
        
        marginLeft = -10;
        
    }

    console.log(style.marginLeft + " Margin left")

    carouselSlider.style.marginLeft =
        (parseInt(style.marginLeft.replace("px", "")) + marginLeft) + "px";


    lastSwipedXPos = e.touches[0].clientX;



}

function navigateToCamera()
{
    mainScreen.classList.add("hide");
    document.getElementById("camera_screen").classList.remove("hide");
    CameraScreen.initCamera(flowerInformation.modelPath, flowerInformation.secondScale)
}

export function initInformation()
{

    try {



        initGames();
        initFlowers();
        
        document.getElementById("navigate_camera").ontouchstart = navigateToCamera;

        imageModal = document.getElementById("start-div");
        document.getElementById("image_anchor").ontouchstart = openImageModal;
        
        document.getElementById("close_button_image_modal").ontouchstart = function () {
            
            imageModal.classList.add("hide");
            document.body.style.overflowY = "scroll";
            document.documentElement.style.overflowY = "scroll";
            
        }
        document.addEventListener("touchmove", function(event){
            event.preventDefault();
        });
        
    
        
        /*carouselSlider = document.getElementById("carousel_slider");
        carouselSlider.addEventListener("touchmove", function (e) {

            swipeCarouselImage(e);
        });*/
  

        console.log(document.getElementById("navigate_camera") + " NAV")
        mainScreen = document.getElementById("main_screen");

   
        console.log(document.getElementById("navigate_camera"))


        const contentTitle = document.getElementById("content_title");

        const contentTitle1 = document.getElementById("content_title1");

        var flowerType = localStorage.getItem("flower");



        if(!listOfFlowers[flowerType])
        {
            flowerType = "FLOWER NOT FOUND!"
        }


        flowerInformation = listOfFlowers[flowerType.toLowerCase()];


        contentTitle.innerHTML = "<b>" + flowerType.substring(0, 1).toUpperCase() +
            flowerType.substring(1)+ "</b>";


        contentTitle1.innerHTML = "<b>" + flowerType.substring(0, 1).toUpperCase() +
            flowerType.substring(1)+ "</b>";

        const contentDescription = document.getElementById("content_description");


        var description;

        if(flowerInformation)
            description = flowerInformation.description;
        else
        {
            description = "";

            document.getElementById("content_button").remove()
        }

        contentDescription.innerHTML = description;


 

        if(!flowerInformation)
            return;

        MainPage.App(flowerInformation.modelPath, flowerInformation.scale);

        var audio = document.createElement("AUDIO")
        
        audio.type = "audio/ogg";

        document.body.appendChild(audio);
        audio.src = flowerInformation.audio;
      

        const audioPlayer = document.getElementById("audio-player");
        const audioPlayerIcon = audioPlayer.querySelector("img");

        audioPlayer.addEventListener("mousedown", function()
        {
         
            
            if(!audioPlaying)
            {
                audioPlayerIcon.src = "./css/main_menu/audio.svg";
                //audioPlayer.style.opacity = 1;
                
                audio.play();
            }
            else
            {
                //audioPlayer.style.opacity = 0.5;

                audioPlayerIcon.src = "./css/main_menu/muted_audio.svg";

                audio.currentTime = 0;  
                audio.pause();
            }
            console.log(audioPlayer.style.opacity)

            audioPlaying = !audioPlaying;
            
        });
  
        console.log(flower + " Flower")

        document.getElementById("content_button").addEventListener("mousedown", function()
        {
            
            /*var html1 = 
                "<div id=\"how_to_play" + "\" " +
                "w3-include-html=\"./pages/games/how_to_play.html\">" +
                "</div>"*/



            
            
            mainScreen.classList.add("hide");
            //document.body.innerHTML = html1 + document.body.innerHTML;
            //w3.includeHTML();
       
            onGameInfoLoad()
         
        
            
            
        });


   
      

        infoInit = true;
    }
    catch(e)
    {
        console.log(e)
        infoInit = false;
    }
    

}


export function onGameInfoLoad()
{
    console.log(flowerInformation.game)
    
    //const gameTitle = document.getElementById("play_content_game_title");
    //const gameDescription = document.getElementById("content_description");
    
    //gameTitle.innerHTML = "<b>" + flowerInformation.game.name + "</b>"
    //gameDescription.innerHTML = flowerInformation.game.description;



    //const startButton = document.getElementById("content_button");
    
    //startButton.ontouchstart = function () {
        console.log("TEST")

        //document.getElementById("how_to_play").remove();
        
        var html2 =
            "<div id=\"" + flowerInformation.game.name + "\" " +
            "w3-include-html=\"./pages/games/" + flowerInformation.game.name.toLowerCase()
                .replace(" ", "_") + ".html\">" +
            "</div>"


        
    

        
        
        document.body.innerHTML = html2 + document.body.innerHTML;
        w3.includeHTML();

        if(flowerInformation.game.name.includes("Falling Genes"))
        {
            FallingGenes.startGame();
        }
        else if(flowerInformation.game.name.includes("Card Flip"))
        {
            CardFlip.startGame();
        }
        else if(flowerInformation.game.name.includes("MCQ"))
        {
            MCQ.startGame();
        }
    //}

}







