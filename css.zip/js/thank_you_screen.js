﻿import * as Main from "./main_screen.js";
import  * as CameraScreen from "./index.js";


export function registerThankYouScreen(lose, message)
{
    console.log(document.getElementById("share_icon"))

    
    

    const shareData = {
        title: 'Share Link',
        text: 'Visit our virtual Genomic Gardens!',
        url: 'https://eqn.zappar.io/870186909373705178/0.1.43/?flower=ciku'
    }


  
    document.getElementById("share_icon").onmousedown = function()
    {
    
        navigator.share(shareData);
    };
    
    console.log(document.getElementById("content_button"))
    
    const resultsTitle = document.getElementById("results_title");
    const resultsDescription = document.getElementById("results_description");


    
    if(lose)
    {
        resultsTitle.textContent = "Keep it up!"
        resultsDescription.style.opacity = 0;
    }
    else
    {

        resultsTitle.textContent = "Good job!";
        resultsDescription.textContent = message;
        resultsDescription.style.opacity = 1;
    }
    
    document.getElementById("play_again_button").onmousedown = function () {

        document.getElementById("thank_you_screen").classList.add("hide");
        Main.onGameInfoLoad();
    }
    
    document.getElementById("back_button").onmousedown = function()
    {
      
        document.getElementById("thank_you_screen").classList.add("hide");
        document.getElementById("main_screen").classList.remove("hide");

        
        Main.initInformation();
        CameraScreen.cameFromGame();
    };
}





