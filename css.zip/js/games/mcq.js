﻿import * as GameManager from "./game_manager.js";
import * as Main from "../main_screen.js";




var scoreUI;
var mcqOptions, questionActualOptions;
var selectedOptionElement = undefined;


var currentQuestionCount = 0;
var currentQuestion;


var questionTitleUI, questionDescUI;

const GREEN_HEX = "#00FF00";

var questions = [];
var score = 0;



function initQuestions()
{
    questions = Main.flowerInformation.gameData;
    console.log(questions)
    
    nextQuestion();
    
}

function nextQuestion()
{

    currentQuestionCount++;
    
    questionTitleUI.textContent = "Question " + currentQuestionCount;
    mcqOptions.forEach((value) => {


       
            

        value.style.outline = "solid black 3px";


        

    })
    
    var randomIndex = Math.floor(Math.random() * questions.length);
    currentQuestion = questions[randomIndex];


    questionDescUI.textContent = currentQuestion.question;
    console.log(currentQuestion)
    
    questions.splice(randomIndex, 1);
    
    console.log(questions)
    
    var count = 0;

    questionActualOptions.forEach((value) => {

        var fetchedQuestion = "";
        var index = 0;
        for (const [key, value] of Object.entries(currentQuestion.options)) {
            
            
            if(count === index)
            {
                fetchedQuestion = value;
                break;
            }
            
            index++;
        }
        
        
        value.textContent = fetchedQuestion;
        count++;
    })
}

function onConfirm()
{
    
    
    

    console.log(currentQuestionCount)
    console.log(questions.length)
    
    if(questions.length === 0)
    {
        GameManager.endGame();
        return;
    }
    
    if(selectedOptionElement.id === currentQuestion.answer)
    {
        score++;
        scoreUI.innerHTML = "<b>" + score + "</b>";
    }


    selectedOptionElement = undefined;
    nextQuestion();
}




export function startGame()
{
    currentQuestionCount = 0;
    questionTitleUI = document.getElementById("question_title")
    questionDescUI = document.getElementById("question_desc");

    mcqOptions = document.querySelectorAll(".question-options");
    questionActualOptions = document.querySelectorAll(".question-actual-question");

    initQuestions();
    

    
    GameManager.initGame(true, function() {}, "MCQ", "Thank you");

    scoreUI = document.getElementById("score");
    

    mcqOptions.forEach((value) => {

        
        value.ontouchstart = function()
        {
            console.log("TEST")
            
            
            
            if(selectedOptionElement !== value)
            {
                value.style.outline = "solid " + GREEN_HEX + " 3px";

                if(selectedOptionElement)
                {
                    selectedOptionElement.style.outline = "solid black 3px";
                }

                selectedOptionElement = value;
            }
      
 
       
    }
        
    })
    
    
    document.getElementById("content_button").ontouchstart = function(event)
    {
        onConfirm();
    }
    
    
    

}