﻿import * as ThankYouScreen from "../thank_you_screen.js";
import * as CameraScreen from "../index.js";
import * as Main from "../main_screen.js";

export var timer = 20, gameStarted = true;
export var timerUI;

const START_TIME = 15;
var savedGameName;

export var lose = true;

export function initGame(timerBoolean, clearGame, gameName, resultsMessage, ...timerVariables)
{
  
    
    if(timerBoolean)
    {


        savedGameName = gameName;
        gameStarted = true;
     
        
       

        timer = START_TIME;
        console.log(timer)

        timerUI = document.getElementById("timer");

        timerUI.innerHTML = "<b>" + START_TIME + "s</b>";
        
        var timerVariable = window.setInterval(function () {

            if(gameStarted)
            {
               
                timer--;
                




                if(timer <= 0)
                {

                    if(timer < 0)
                        timer = 0;

                    gameStarted = false;
                    clearAllTimers(timerVariable, timerVariables)


                    clearGame();
                    document.getElementById(gameName).remove();


                    document.getElementById("thank_you_screen").classList.remove("hide");

                    ThankYouScreen.registerThankYouScreen(lose, resultsMessage);






                }

                timerUI.innerHTML = "<b>" + timer + "s</b>";

            }

        }, 1000);
        
    }


    const backButton = document.getElementById("back-button");

    backButton.ontouchstart = function () {

        clearAllTimers(timerVariable, timerVariables)

        
 
        //CameraScreen.cameFromGame();

        document.getElementById(gameName).remove();


        document.getElementById("thank_you_screen").classList.remove("hide");


        ThankYouScreen.registerThankYouScreen(true);
  


        clearGame();



        //Main.initInformation();

    }
}


function clearAllTimers(timerVariable, timerVariables)
{


    window.clearInterval(timerVariable);
    for(let i = 0; i < timerVariables.length; i++)
    {
        
        window.clearInterval(timerVariables[i]);
    }
    
}

export function setTimer(newTime)
{
    
    console.log(timer + " TIMER")
    timer = newTime;
}

export function getTimer()
{
    console.log(timer + " GET TIME")
    return timer;
}

export function setGameStarted(started)
{
    gameStarted = started;
}


export function endGame()
{
    timer = 2;
}

export function setLose(newValue)
{

    
    lose = newValue;
}